
###################calling python directories###############################
#############I m using pandas functionalities to clean data, wrangle data and display data in the formats as per assignment requirement--

import csv # reading and writing to CSV files
import datetime # operations to parse dates
from pprint import pprint # use to print data structures like dictionaries in
                          # a nicer way than the base print function.
import pandas as pd # converts CSV files into dataframes
import numpy as np # performs calculations
import matplotlib as mpl # Still required to change the sizes of plots 
import calendar
import sys

###### used to display pandas output
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

##### global variables
chicago = 'chicago.csv'
new_york_city = 'new_york_city.csv'
washington = 'washington.csv'

def get_city():
    
    '''
    This function is used to return the filename of the keyed-in city name. Incorrect names entered are rejected; input is thrown back to retry.
    Input : None
    Returns : Filename corresponding to the city
    '''

    city = input('\nHello! Let\'s explore some US bikeshare data!\n'
                 'Would you like to see data for Chicago, New York, or Washington?\n')
    if city == "Chicago":
        return chicago
    elif city == "New York":
        return new_york_city
    elif city == "Washington":
        return washington        
    
    else:
        print("\nError in input - Please enter Chicago or New York or Washington")
            
        restart = input('\nWould you like to restart? Type \'yes\' or \'no\'.\n')
            
        if restart.lower() == 'yes':
            calling_function()        
        elif restart.lower() == 'no':
            sys.exit("Error message")
                

def filter_me_by():

    '''
    This function is used to filter the keyed-in values. Possible values to be entered as 'month' or 'day' or 'none'.
    'month' would display the entire month's data for the city chosen.
    'day' would display the entire day's data for the city chosen.
    'none' would display the entire dataset of the city without any filters applied.

    Input : None
    Returns : filter called as 'time_period' corresponding to the city
    '''

    time_period = input('\nWould you like to filter the data by month, day, or none?\n')
    
    if time_period == "month":
        t = 1
    elif time_period == "day":
        t = 1
    elif time_period == "none":
        t = 1
    else:
        t = 2
    
        if t == 2:
            
            print("\nError in input - Please enter month or day or none")
            
            restart = input('\nWould you like to restart? Type \'yes\' or \'no\'.\n')
            
            if restart.lower() == 'yes':
                calling_function()        
            elif restart.lower() == 'no':
                sys.exit("Error message")        
    
    return time_period

def filter_me_by_month():

    '''
    This function is used to keyed-in month values. Possible values to be entered are month names for first 6 months of the year - 
    'January' or 'February' or 'March' or 'April' or 'May' or 'June'.
    Please ensure month names are correctly entered as above otherwise you will be re-prompted for a restart.

    Input : None
    Returns : month name chosen corresponding to the city
    '''
    month = input('\n Enter month name as January or February or March or April or May or June\n')
    if month == "January":
        month = 1
    elif month == "February":
        month = 2
    elif month == "March":
        month = 3
    elif month == "April":
        month = 4
    elif month == "May":
        month = 5
    elif month == "June":
        month = 6
    else:
        month = 7
        
    if month == 7:
        print("Error in input - Please enter January or February or March or April or May or June\n")
                
        restart = input('\nWould you like to restart? Type \'yes\' or \'no\'.\n')
        if restart.lower() == 'yes':
            calling_function()        
        elif restart.lower() == 'no':
            sys.exit("Error message")
    
    return month

def filter_me_by_day():

    '''
    This function is used to keyed-in day values. Possible values to be entered are day names for the week - 
    'Sunday' or 'Monday' or 'Tuesday' or 'Wednesday' or 'Thursday' or 'Friday' or 'Saturday'.
    Please ensure day names are correctly entered as above otherwise you will be re-prompted for a restart.

    Input : None
    Returns : day name chosen corresponding to the city
    '''

    day = input('\nWould you like to filter by Sunday, Monday, Tuesday, Wednesday, Thursday, Friday or Saturday?\n')
    if day == "Sunday":
        day = 1
    elif day == "Monday":
        day = 2
    elif day == "Tuesday":
        day = 3
    elif day == "Wednesday":
        day = 4
    elif day == "Thursday":
        day = 5
    elif day == "Friday":
        day = 6
    elif day == "Saturday":
        day = 7
    else:
        day = 8
        
    if day == 8:
        print("Error in input - Please enter Sunday, Monday, Tuesday, Wednesday, Thursday, Friday or Saturday\n")
                
        restart = input('\nWould you like to restart? Type \'yes\' or \'no\'.\n')
        if restart.lower() == 'yes':
            calling_function()        
        elif restart.lower() == 'no':
            sys.exit("Error message")
        
    return day
        
def calling_function():

    '''
    This function is used call other functions in the program; also called as 'main calling function'. It filters the output and calls corresponding calculation functions.
    '''

    # Filter by city (Chicago, New York, Washington)
    city = get_city()

    #filter by month or day or none    
    filter_by = filter_me_by()        
    
    if filter_by == "month":
        filter_by_me = filter_me_by_month()
        open_file = main(city,filter_by,filter_by_me)
        
    if filter_by == "day":
        day = filter_me_by_day()
        open_file = main(city,filter_by,day)
        
    if filter_by == "none":
        open_file = main_option_none(city)        
    
def main_option_none(filename):

    '''
    This function is used calculate major statistics; this is called by calling_function. This function is only called for option to display all data
    with no filters added
    Input : filename
    '''

    print("\n Displaying ouput and calculating the statistics \n")
    print("\n ----------------------------------------------- \n")
    print("\n ----------------------------------------------- \n") 
    print("\n ----------------------------------------------- \n")

            
    df = pd.read_csv(filename)
    
    print(df.head(5))
    
    a = input("\n Do you want to see another 10 records ? Type Y or N. Type All to display all the contents. \n")
    
    if a == "Y" or a == "y":
        print(df.head(10))
    elif a == "N" or a == "n":
        print("\n")
    elif a == "All" or a == "all":
            print(df[a])
    else:
        print("Error in input; displaying the statistics of the dataset now.\n")        
        print("\n")
        print("\n")
        print("\n")
    
    print("\n Now lets display the statistics of the dataset for chosen city")

    print("\n --------------------------------------------------------------\n")
    print("\n --------------------------------------------------------------\n")
    print("\n") 
    print("\n")    
    
    n_subscribers, n_customers, n_total = number_of_trips(filename)
    print("Total number of User Type as Subscribers is : ", n_subscribers)
    print("Total number of User Type as Customers is ", n_customers)
    print("Total number of Users in biker data for chosen file is : ", n_total)
    print("Total Proportion of subscribers is : ", n_subscribers/n_total)
    print("Total Proportion of customers is : ", n_customers/n_total)
    print("\n") 

    average_travel, proportion = travel_time_stats(filename)
    print("Average travel time in (min) for the trips is : ", average_travel)
    print("Proportion over 30 mins is : ", proportion)
    print("\n")        
        

    if filename == "chicago.csv" or filename == "new_york_city.csv":
        df = pd.read_csv(filename)
        p_male, p_female = count_gender(filename)
        print("Total number of Male bikers: ", p_male)
        print("Total number of Female bikers: ", p_female)
        print("\n")
    
    #########popular data calculation
    
    p_month, p_day, p_hour, p_start_station, p_end_station = popular_data_display(filename)
    
    print("\n")
    print("The most popular month in the dataset is : ", p_month)
    
    print("The most popular day in the dataset is: ", p_day)
    print("\n")   
    
    print("The most Popular Hour in the dataset is: ", p_hour)
    print("\n")   
    
    
    print("The most popular Start Station in the dataset is: ", p_start_station)
    print("\n")   
    print("The most popular End Station in the dataset is: ", p_end_station)
    print("\n")       
    
    print("--------End of the output------")

def main(filename,filter,filter_by_name):

    '''
    This function is used calculate major statistics; this is called by calling_function. This function is only called for option to display data
    with filtering by month or day.
    Input : filename, filter by day or month
    '''    
    
    print("\n Displaying ouput and calculating the statistics \n")
    print("\n ----------------------------------------------- \n")
    print("\n ----------------------------------------------- \n") 
    print("\n ----------------------------------------------- \n")
    
    df = pd.read_csv(filename)
    
    df['Month'] = pd.DatetimeIndex(df['Start Time']).month
    
    df['Day'] = pd.DatetimeIndex(df['Start Time']).day
    
    #####for a given month or a day
    
    if filter == "month":

        a = df['Month'] == filter_by_name

        print(df[a].head(5))

        b = input("\n Do you want to see another 10 records ? Type Y or N. Type All to see all records. \n")
    
        if b == "Y" or b == "y":
            print(df[a].head(10))
        elif b == "All" or b == "all":
            print(df[a])
        elif b == "N" or b == "n":
            print("\n")

        else:
            print("Error in input; displaying the statistics of the dataset now.\n")        
            print("\n")
            print("\n")
            print("\n")
                                    
    print("\n Now lets display the statistics of the dataset for chosen city")                
        
    if filter == "day":

        a = df['Day'] == filter_by_name
        
        print(df[a].head(5))        
        
        b = input("\n Do you want to see another 10 records ? Type Y or N. Type All to see all records. \n")
    
        if b == "Y" or b == "y":
            print(df[a].head(10))
        elif b == "All" or b == "all":
            print(df[a])
        elif b == "N" or b == "n":
            print("\n")            
        else:
            print("Error in input; displaying the statistics of the dataset now.\n")        
            print("\n")
            print("\n")
            print("\n")            
    
    print("\n Now lets display the statistics of the dataset for chosen city")        
    print("\n")
    print("\n")
    
    n_subscribers, n_customers, n_total = number_of_trips(filename)
    print("Total number of subscribers in the dataset is : ", n_subscribers)
    print("Total number of customers in the dataset is: ", n_customers)
    print("Total number of user types (subscribers and customers) in the dataset is : ", n_total)
    print("The proportion of subscribers: ", n_subscribers/n_total)
    print("The proportion of customers: ", n_customers/n_total)
    print("\n") 

    average_travel, proportion = travel_time_stats(filename)
    print("The Average Travel time (min) in the dataset is : ", average_travel)
    print("The proportion of travel over 30 mins: ", proportion)
    print("\n")        

    if filename == "chicago.csv" or filename == "new_york_city.csv":
        df = pd.read_csv(filename)
        p_male, p_female = count_gender(filename)
        print("Total number of Male bikers in the dataset is : ", p_male)
        print("Total number of Female bikers in the dataset is : ", p_female)
        print("\n")
    
    #########popular data calculation
    
    p_month, p_day, p_hour, p_start_station, p_end_station = popular_data_display(filename)

    print("\n")
    print("Popular Month is : ", p_month)
    
    print("Popular Day is: ", p_day)
    print("\n")   
    
    print("Popular Hour is : ", p_hour)
    print("\n")   
    
    print("Popular Start Station is: ", p_start_station)
    print("\n")   
    print("Popular End Station is: ", p_end_station)
    print("\n")       

    print("--------End of the output------")    
    

def get_trip_times(file, cust_type=None):

    '''
    This function takes in a file and returns a list off all trip times for a particular city (correlating to file) 
    Input - file - string containing the name of the .csv file
    Returns - duration time
    '''
    duration_times = []
    with open(file, 'r') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        
        if cust_type:
            duration_times = [float(row['Trip Duration']) for row in csv_reader if row['User Type'] == cust_type]
        else:        
            #create list of trip duration times
            duration_times = [float(row['Trip Duration']) for row in csv_reader if row['Trip Duration']]

        return duration_times

def count_gender(filename):


    '''
    used to calculate count of gender
    Input : filename
    Returns : count of male and female riders
    '''
    
    df = pd.read_csv(filename)

    male_count = len(df[(df['Gender']=="Male")])
    female_count = len(df[(df['Gender']=="Female")])
            
    return male_count, female_count

def number_of_trips(filename):
    
    '''
    This function reads in a file with trip data and reports the number of
    trips made by subscribers, customers, and total overall.
    '''
    
    # Create dataframe
    df = pd.read_csv(filename)
    
    # initialize count variables
    n_subscribers = len(df[df['User Type']=='Subscriber'])
    n_customers = len(df[df['User Type']=='Customer'])
    
    # compute total number of rides
    n_total = n_subscribers + n_customers

    # return tallies as a tuple
    return(n_subscribers, n_customers, n_total)

def proportion_overtime(filename):
    
    '''
    This function calculates the proportion of subscribers relative to 
    total clients' travel time where the duration of the trip is higher 
    than 30 of the CSV summaries. Input is the file path and the returned 
    value is a float.
    '''
    # Create dataframe
    df = pd.read_csv(filename)
    
    # Filter dataframe to contain longer rides
    df2 = df[df['Trip Duration']>30]
    
    # Calculate proportion subscribers and customer
    p_customer = len(df2[df2['User Type'] == 'Customer'])/len(df2)
    p_subscriber = len(df2[df2['User Type'] == 'Subscriber'])/len(df2)
    
    p_customer_count = len(df[df['User Type'] == 'Customer'])
    p_subscriber_count = len(df[df['User Type'] == 'Subscriber'])
    
    #return p_customer, p_subscriber
    
    return p_customer_count, p_subscriber_count

def popular_data_display(filename):

    '''
    Used to display popular functions
    Input : filename
    Returns : max_month, max_day, max_hour, max_start_station, max_end_station
    '''
    
    df = pd.read_csv(filename)
    
    df['Month'] = pd.DatetimeIndex(df['Start Time']).month
    
    df['Day'] = pd.DatetimeIndex(df['Start Time']).day

    df['Hour'] = pd.DatetimeIndex(df['Start Time']).hour

    b = df['Month'].value_counts()
        
    max_month = df.groupby('Month')['Month'].count().idxmax()

    max_day = df.groupby('Day')['Day'].count().idxmax()        
    
    max_hour = df.groupby('Hour')['Hour'].count().idxmax()        

    if max_month == 1:
        max_month = "January"
    elif max_month == 2:
        max_month = "February"
    elif max_month == 3:
        max_month = "March"  
    elif max_month == 4:
        max_month = "April"
    elif max_month == 5:
        max_month = "May"
    elif max_month == 6:
        max_month = "June"        

    if max_day == 0:
        max_day = "Sunday"
    elif max_day == 1:
        max_day = "Monday"
    elif max_day == 2:
        max_day = "Tuesday"  
    elif max_day == 3:
        max_day = "Wednesday"
    elif max_day == 4:
        max_day = "Thursday"
    elif max_day == 5:
        max_day = "Friday"        
    elif max_day == 6:
        max_day = "Saturday"    

####################start station

    #c = df['Start Station'].value_counts()
        
    max_start_station = df.groupby('Start Station')['Start Station'].count().idxmax()
    
####################End station

    #c = df['End Station'].value_counts()    
    
    max_end_station = df.groupby('End Station')['End Station'].count().idxmax()
    
    #print(max_end_station)    
    
####################max trip##############

    #d = df['Trip Duration'].max()
    
    e = df.loc[df['Trip Duration'].idxmax()]
    
###################birthdate##########

######most popular birth years############

    if filename == "chicago.csv" or filename == "new_york_city.csv":
        df = pd.read_csv(filename)
        max_birth_year = df.groupby('Birth Year')['Birth Year'].count().idxmax()
        print("\nMost Popular Birth Year in the dataset is: ", max_birth_year)

###########newest birthyear
    
        e = df.loc[df['Birth Year'].idxmax()]
        
        print("\nRow containing about the Newest birth year in the dataset is displayed below - \n")
        print(e)

        f = df.loc[df['Birth Year'].idxmin()]
        
        print("\nRow containing about the Newest birth year in the dataset is displayed below - \n")
        print(f)    
    
    return max_month, max_day, max_hour, max_start_station, max_end_station#, max_birth_year
    
def travel_time_stats(filename):

    '''
    This function calculates the average travel time of the CSV summaries.
    Input is the file path and the returned value is a float.
    '''

    # Create dataframe
    df = pd.read_csv(filename)
    
    # Calculate average
    average = np.average(df['Trip Duration'])
    
    # Calculate proportion of rides above 30 mins
    proportion = len(df[df['Trip Duration']>30])/len(df)

    return average, proportion
        
if __name__ == "__main__":
    calling_function()

